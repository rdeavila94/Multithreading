
public class TaskThread_main {

	public static void main(String[] args) {
		int NUM = 3;
		int current = 0;
		Thread r1 = new Thread();
		Thread r2 = new Thread();
		while (current <= NUM) {
			if (!r1.isAlive()) {
				r1 = new Thread(new TaskThread(current));
				current++;
				r1.start();
			}
			if (!r2.isAlive()) {
				r2 = new Thread(new TaskThread(current));
				current ++;
				r2.start();
			}
		}	
	}
}
